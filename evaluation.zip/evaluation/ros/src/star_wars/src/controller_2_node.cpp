/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *     
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic types you use.
#include <tf/transform_listener.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/Twist.h>
// Your callback functions here if any. With a reasonable function name...
// ...
//
//void myFirstCallback(/* Define here the variable which holds the message */){
//    // ... Callback function code
//}


// Take an angle to [-pi,pi[ interval whatever its initial value.
double limit_angle(double a){
    while( a >=  M_PI ) a -= 2*M_PI ;
    while( a <  -M_PI ) a += 2*M_PI ;
    return a ;
}
 
int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "controller_2_node");

    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~") ;

    // Read the node parameters if any
    // ...

    // Declare your node's subscriptions and service clients
    // A subscriber looks like this:
    // ros::Subscriber subsName = some_node_handler.subscribe<pacakage::Type>("topic_name_here",buffer_size_often_1,yourCallBackFn) ;
    // ...
    std::string leader;
    std::string follower; 
    std::string name;
    nh_loc.getParam("leader",leader);
    nh_loc.getParam("follower",follower);
    nh_loc.getParam("name",name);
    // Declare you publishers and service servers
    // Publisher looks like this: 
    ros::Publisher pubvelocity = nh_glob.advertise<geometry_msgs::Twist>(name,1) ;
    
    // Intializations may be required here.
    // ...
    tf::TransformListener listener;  
    
    geometry_msgs::Twist velocity;
    velocity.linear.x=0;
    velocity.angular.z=0;
    double kp=2.7, ka=2.9;  
    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        // The code of your node goes here.
        tf::StampedTransform transform;
        try{
            listener.lookupTransform(follower, leader, ros::Time(0), transform);
            }
        catch (tf::TransformException &ex) {
           ROS_ERROR("%s",ex.what());
           continue ;
        };
        double xl=transform.getOrigin().x();
        double yl=transform.getOrigin().y();
        double alpha=atan2(yl,xl);
        double p=xl-1;
        velocity.linear.x=kp*p;
        velocity.angular.z=ka*alpha;
        pubvelocity.publish(velocity);
        rate.sleep();
    }
}

