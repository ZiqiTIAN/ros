
"use strict";

let NameAndPose = require('./NameAndPose.js');

module.exports = {
  NameAndPose: NameAndPose,
};
