/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"
#include <tf/transform_listener.h>
#include <geometry_msgs/PoseStamped.h>
// #include <dual_planar_arm_msgs/DualArmIK.h>
// Include here the ".h" files corresponding to the topic type you use.
using namespace std;
int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "left_arm_tracker");
    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~"), node;
    tf::TransformListener listener;
    geometry_msgs::PoseStamped goalposition;
    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        // Your code here.
        tf::StampedTransform transform;
        try{
            listener.lookupTransform("r_arm_base", "goal", ros::Time(0), transform);
            }
        catch (tf::TransformException &ex) {
           ROS_ERROR("%s",ex.what());
           continue ;
        };
        goalposition.pose.position.x=transform.getOrigin().x();
        goalposition.pose.position.y=transform.getOrigin().y();
        std::cout<<"x = "<< goalposition.pose.position.x <<" y = " << goalposition.pose.position.y <<std::endl;
        // goal_position.publish(goalposition);
        rate.sleep();
    }
}

