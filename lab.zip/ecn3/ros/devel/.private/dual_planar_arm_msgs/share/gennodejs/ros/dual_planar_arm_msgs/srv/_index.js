
"use strict";

let DualArmIK = require('./DualArmIK.js')

module.exports = {
  DualArmIK: DualArmIK,
};
