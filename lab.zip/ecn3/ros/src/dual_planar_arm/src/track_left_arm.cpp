/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"
#include <tf/transform_listener.h>
#include <geometry_msgs/PoseStamped.h>
#include <dual_planar_arm_msgs/DualArmIK.h>
// Include here the ".h" files corresponding to the topic type you use.
using namespace std;
int main (int argc, char** argv)
{

	//ROS Initialization
    ros::init(argc, argv, "left_arm_tracker");
    // Define your node handles: YOU NEED AT LEAST ONE !
    ros::NodeHandle nh_glob, nh_loc("~"), nh_;
    ros::service::waitForService("right_arm_IK_service");
    ros::ServiceClient right_arm = nh_.serviceClient<dual_planar_arm_msgs::DualArmIK>("right_arm_IK_service");
    dual_planar_arm_msgs::DualArmIK srv;
    right_arm.call(srv);

    ros::Publisher pubjoint = nh_glob.advertise<sensor_msgs::JointState>("/joint_command",1) ;
    sensor_msgs::JointState joint;
    tf::TransformListener listener;
    geometry_msgs::PoseStamped goalposition;
    ros::Rate rate(50);   // Or other rate.
    while (ros::ok()){
        ros::spinOnce();

        // Your code here.
        tf::StampedTransform transform;
        try{
            listener.lookupTransform("r_arm_base", "goal", ros::Time(0), transform);
            }
        catch (tf::TransformException &ex) {
           ROS_ERROR("%s",ex.what());
           continue ;
        };
        if( !right_arm.exists() ){
			ROS_ERROR("Service does not exist.");
			continue ;
		}
        if( !right_arm.isValid() ){
			ROS_ERROR("Service not ready.");
			continue ;
		}
        goalposition.pose.position.x=transform.getOrigin().x();
        goalposition.pose.position.y=transform.getOrigin().y();
        srv.request.goal.header.frame_id="r_arm_base";
        srv.request.goal.point.x=goalposition.pose.position.x;
        srv.request.goal.point.y=goalposition.pose.position.y;
		if ( !right_arm.call(srv )){
                ROS_ERROR("CALL TO SERVICE FAILED");
            }
            else
            {
                if (srv.response.solutions.size()!=0){
                    std::cout << "q = " << srv.response.solutions[0] << std::endl;
                    joint=srv.response.solutions[0];
                }
                else{
                    std::cout << "there is no solution" << std::endl;
                }
            }
        // std::cout<<"x = "<< goalposition.pose.position.x <<" y = " << goalposition.pose.position.y <<std::endl;
        pubjoint.publish(joint);
        rate.sleep();
    }
}

