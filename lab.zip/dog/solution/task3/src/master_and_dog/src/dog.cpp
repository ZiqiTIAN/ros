/**
 * \file
 * \brief 
 * \author 
 * \version 0.1
 * \date 
 * 
 * \param[in] 
 * 
 * Subscribes to: <BR>
 *    ° 
 * 
 * Publishes to: <BR>
 *    ° 
 *
 * Description
 *
 */


//Cpp
#include <sstream>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <math.h>

//ROS
#include "ros/ros.h"

// Include here the ".h" files corresponding to the topic type you use.
#include <std_msgs/Int16.h>
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/Point.h>
#include <std_msgs/Float64.h>

// You may have a number of globals here.
geometry_msgs::Point dogposition ;
std_msgs::Float64 dogspeed;

ros::Publisher pubMarker ;
visualization_msgs::Marker marker;
// Callback functions...
void initializeMarker(){
    std::string nodeName ;
    nodeName = ros::this_node::getName();
    // Create a marker for this node. Only timestamp and position will be later updated.
    marker.header.frame_id = "/map";
    marker.ns = nodeName;
    marker.id = 0;
    marker.type = visualization_msgs::Marker::CUBE;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.1;
    marker.scale.y = 0.1;
    marker.scale.z = 0.1;
    marker.color.r = 1.0f;
    marker.color.g = 0.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;
}

void publishMarkerAt( geometry_msgs::Point markerPos) {    
    marker.header.stamp = ros::Time::now();
    marker.pose.position.x = markerPos.x ;
    marker.pose.position.y = markerPos.y ;
    marker.pose.position.z = 0;
    marker.lifetime = ros::Duration();
    pubMarker.publish(marker);
}

double u_x, u_y;
void directionCallback(geometry_msgs::Point masterposition)
{
    //double lengthab=sqrt((masterposition.x-dogposition.x).^2+(masterposition.y-dogposition.y).^2);
    double lengthux=masterposition.x-dogposition.x;
    double lengthuy=masterposition.y-dogposition.y;
    double lengthab=sqrt(lengthux*lengthux+lengthuy*lengthuy);
    u_x=lengthux/lengthab;
    u_y=lengthuy/lengthab;
}


int main (int argc, char** argv)
{

    //ROS Initialization
    ros::init(argc, argv, "dog");

    // Define your node handles
    ros::NodeHandle nh_loc("~") ;
    ros::NodeHandle nh_glob ;

    // Read the node parameters if any
    // ...

    // Declare your node's subscriptions and service clients
    ROS_INFO("SUbscribing to topics\n");
    //ros::Subscriber speedSub = nh_glob.subscribe<std_msgs::Float64>("/speed",1,myCallback) ;
    ros::Subscriber positionSub = nh_glob.subscribe<geometry_msgs::Point>("/position",1,directionCallback) ;
    // Declare you publishers and service servers
                     pubMarker         = nh_glob.advertise<visualization_msgs::Marker>("/visualization_marker",1) ;
    ros::Publisher pubspeed = nh_glob.advertise<std_msgs::Float64>("/dogspeed",1);
    ros::Publisher pubposition = nh_glob.advertise<geometry_msgs::Point>("/dogposition",1);

    ros::Rate rate(50);   // Or other rate.
    dogposition.x = 0;
    dogposition.y = 0;
    dogposition.z = 0;
    dogspeed.data = 1;
        initializeMarker() ;
    publishMarkerAt( dogposition ) ;

    ros::Time currentTime, prevTime = ros::Time::now() ;
    while (ros::ok()){
        ros::spinOnce();

        // Your node's code goes here.
        currentTime = ros::Time::now() ;
        ros::Duration timeElapsed = currentTime - prevTime ;
        prevTime = currentTime ;
        dogposition.x = dogposition.x + u_x * dogspeed.data * timeElapsed.toSec();
        dogposition.y = dogposition.y + u_y * dogspeed.data * timeElapsed.toSec();
        
        publishMarkerAt( dogposition ) ;
        pubspeed.publish( dogspeed ) ;
        pubposition.publish( dogposition ) ;

        rate.sleep();
    }
}
